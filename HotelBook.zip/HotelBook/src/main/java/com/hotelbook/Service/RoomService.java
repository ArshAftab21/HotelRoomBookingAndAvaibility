package com.hotelbook.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hotelbook.Model.BookingDetails;
import com.hotelbook.Model.Room;
import com.hotelbook.Model.RoomBlock;
import com.hotelbook.Repository.RoomBlockRepository;
import com.hotelbook.Repository.RoomRepository;

@Service
public class RoomService {

	@Autowired
	RoomRepository roomRepository;

	@Autowired
	RoomBlockRepository roomBlockrepository;

	@Transactional
	public List<Integer> getroomList() {
		List<Room> list = (List<Room>) roomRepository.findAll();
		List<Integer> roomList = new ArrayList<Integer>();
		
		for (Room r : list) {
			roomList.add(r.getRoomNo());
		}
		return roomList;
	}

	@Transactional
	public void addRooms() {
		// TODO Auto-generated method stub
		Room r1 = new Room(1004);
		roomRepository.save(r1);
		Room r2 = new Room(1005);
		roomRepository.save(r2);
		Room r3 = new Room(1006);
		roomRepository.save(r3);

	}

	@Transactional
	public void bookRoom(String roomNo, String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d = sdf.parse(date);
		Integer roomNum = Integer.parseInt(roomNo);
		Room room=roomRepository.findbyRoomNumber(roomNum);
		RoomBlock roomBlock=new RoomBlock();
		roomBlock.setRoom(room);
		roomBlock.setDate(d);
		roomBlock.setStatus("Booked");
		roomBlockrepository.save(roomBlock);
	}

	@Transactional
	public List<BookingDetails> getBookingList() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<BookingDetails> rList=new ArrayList<BookingDetails>();
		List<RoomBlock> rb=(List<RoomBlock>)roomBlockrepository.findAll(); 
		for(RoomBlock rB:rb)
		{
			BookingDetails bd=new BookingDetails();
			bd.setRoomNumber(rB.getRoom().getRoomNo());  
			bd.setDate(sdf.format(rB.getDate()));
			rList.add(bd);
		}
		return rList;
	}

	@Transactional
	public boolean checkAvailability(String roomNo, String date) throws ParseException {
		boolean result=false;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d = sdf.parse(date);
		Integer roomNum = Integer.parseInt(roomNo);
		List<RoomBlock> rbList=roomBlockrepository.getRoomBlocks(d);
		for(RoomBlock rb:rbList)
		{
			if(rb.getRoom().getRoomNo()==roomNum)
			{
				result=true;
			}
		}
		return result;
		
	}

}
