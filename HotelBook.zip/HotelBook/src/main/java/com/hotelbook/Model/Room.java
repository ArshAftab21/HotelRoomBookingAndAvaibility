package com.hotelbook.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Room {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int roomId;
	private int roomNo;
	@OneToMany(mappedBy = "room", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<RoomBlock> rb=new ArrayList<RoomBlock>();
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public List<RoomBlock> getRb() {
		return rb;
	}
	public void setRb(List<RoomBlock> rb) {
		this.rb = rb;
	}
	public Room(int roomNo) {
		super();
		this.roomNo = roomNo;
	}
	public Room() {
		
		
	}

}
