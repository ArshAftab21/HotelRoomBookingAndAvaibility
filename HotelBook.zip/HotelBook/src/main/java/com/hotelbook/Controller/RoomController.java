package com.hotelbook.Controller;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hotelbook.Model.BookingDetails;
import com.hotelbook.Service.RoomService;

@Controller
public class RoomController {
	
	
	@Autowired(required=true)
	RoomService roomService;
	
	
	@RequestMapping("/")
	public String homePage() {
		
		return "Home";
	}
	
	@RequestMapping("/bookingPage")
	public String bookingPage() {
		
		return "HotelBook";
	}
	
	@RequestMapping(value = "/roomList", produces = "application/json")
	public @ResponseBody List<Integer> getRoom() {
		// Method to fetch list of hotel room 
		//roomService.addRooms();
		List<Integer> result = roomService.getroomList();
		return result;
	}
	
	@RequestMapping(value="/bookRoom", method = RequestMethod.POST)
	public ModelAndView bookRoom(HttpServletRequest request,Model model) throws ParseException
	{
		String roomNo=request.getParameter("roomno");
		String date=request.getParameter("date");
		boolean result=roomService.checkAvailability(roomNo,date);
		if(result==true)
		{
			model.addAttribute("Status","Not Available for Date Selected");
		}
		else
		{
		roomService.bookRoom(roomNo,date);
		model.addAttribute("Status","Room Booked");
		}
		return new ModelAndView("HotelBook");
	}
	
	@RequestMapping(value="fetchBookingList")
	public @ResponseBody List<BookingDetails> fetchBookingList() {
		// Method to fetch list of hotel room 
		//roomService.addRooms();
		List<BookingDetails> rList = roomService.getBookingList();
		
		return rList;
	}

}
