package com.hotelbook.Repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hotelbook.Model.Room;

@Repository
public interface RoomRepository extends CrudRepository<Room,Integer> {

	@Query("from Room r where r.roomNo=:roomNum")
	Room findbyRoomNumber(@Param("roomNum")Integer roomNum);

}
