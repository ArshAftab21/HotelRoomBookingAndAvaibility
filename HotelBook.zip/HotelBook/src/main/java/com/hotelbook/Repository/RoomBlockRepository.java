package com.hotelbook.Repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.hotelbook.Model.RoomBlock;

@Repository
public interface RoomBlockRepository extends CrudRepository<RoomBlock,Integer>{

	@Query("from RoomBlock rb where rb.date=:date")
	public List<RoomBlock> getRoomBlocks(@Param("date")Date date);
}
